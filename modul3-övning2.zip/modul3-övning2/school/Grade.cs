﻿namespace modul3_övning2.school
{
    public class Grade
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}